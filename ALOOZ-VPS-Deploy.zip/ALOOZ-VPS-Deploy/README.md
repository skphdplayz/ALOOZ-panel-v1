# ALOOZ VPS Deploy Bot

Admin-only Discord slash-command bot for managing **VPSs you own or are explicitly authorized to administer** over SSH, and deploying Node.js applications/Discord bots from public GitHub repositories.

## Included commands

- `/add-vps` — add an authorized Linux VPS using its SSH host, username and the **private-key path on the bot machine**
- `/vps-list` — list registered VPSs
- `/vps-status` — hostname, uptime, disk and memory summary
- `/deploy-node` — clone/update a public GitHub repo and create a systemd service
- `/app-restart` — restart a deployed app
- `/remove-vps` — remove a VPS from this bot's inventory (does not destroy the VPS)

## Requirements

- Ubuntu 22.04/24.04 recommended for the bot host
- Node.js 20+
- Discord application and bot token
- SSH access to each target VPS
- Target VPS: `git`, Node.js 20+, `sudo` permission for the configured SSH user

## Install from GitHub

After uploading this folder to a **public** GitHub repository, run on your Ubuntu bot host as a normal sudo-capable user:

```bash
REPO_URL=https://github.com/YOUR_GITHUB_USERNAME/ALOOZ-VPS-Deploy.git bash -c 'curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/ALOOZ-VPS-Deploy/main/install.sh | bash'
```

Replace `YOUR_GITHUB_USERNAME` and repository name with your actual values. The installer creates `.env` but does not ask for or upload your Discord token.

Alternative: clone the repo, then run `bash install.sh` from inside the cloned folder.

## Configure Discord

1. Create a Discord application at https://discord.com/developers/applications.
2. Add a Bot and copy its token.
3. Invite it with `bot` and `applications.commands` scopes. It needs no Administrator permission.
4. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
   - `GUILD_ID`
   - `ADMIN_IDS` (your Discord user ID; comma-separated IDs allowed)
5. Protect the file: `chmod 600 .env`
6. Register commands: `npm run register`
7. Start: `npm start`

## Add a target VPS securely

On the bot host, create a dedicated SSH key:

```bash
ssh-keygen -t ed25519 -f "$HOME/.ssh/alooz_deploy" -C alooz-deploy
chmod 600 "$HOME/.ssh/alooz_deploy"
```

Install the **public** key on each target VPS for a dedicated, non-root deployment user. Do not copy the private key to target VPSs or GitHub. Confirm that the bot host can connect:

```bash
ssh -i "$HOME/.ssh/alooz_deploy" deployuser@TARGET_VPS_IP
```

Then use `/add-vps` in Discord. Set `key_path` to the private key's absolute path on the bot host, e.g. `/home/ubuntu/.ssh/alooz_deploy`.

The deploy user needs narrowly scoped sudo rights for the systemd service operations and ownership of `/opt/alooz-apps`. Avoid unrestricted passwordless sudo where possible. The current starter implementation uses sudo for systemd and directory setup; review and tighten sudoers before production use.

## Deploy a Discord bot / Node.js app

Use `/deploy-node` with:
- `vps`: registered VPS label
- `app`: lowercase service name, e.g. `my-discord-bot`
- `repo`: public GitHub URL, e.g. `https://github.com/example/my-bot`
- `branch`: optional, defaults to `main`

The repository must define a working `npm start` script. Deploying code executes that repository's install scripts and app code on the target VPS. Only deploy repositories you trust and control.

## Important security notes

- Never commit `.env`, Discord tokens, SSH private keys, or `data/servers.json`.
- Use a dedicated non-root Linux account on each target VPS.
- Restrict bot usage with `ADMIN_IDS`; do not rely only on Discord channel permissions.
- Back up `data/servers.json`; it stores hostnames, usernames and private-key file paths, not private-key contents.
- SSH host-key verification is currently permissive in this starter template. Before production, pin each server's SSH host fingerprint in `src/ssh.js` and replace the permissive `hostVerifier`.
- `/remove-vps` only removes the saved connection record. It does not delete a VPS.
- This is a starter project, not a cloud-provider provisioning API. It manages existing VPSs over SSH; creating new cloud instances requires provider-specific APIs.

## Troubleshooting

- `Missing DISCORD_TOKEN`: configure `.env`.
- Commands not visible: check `CLIENT_ID`, `GUILD_ID`, invite scopes, then run `npm run register`.
- SSH fails: verify key path, permissions, username, port, firewall and public-key installation.
- Deploy fails: ensure target VPS has Node.js 20+, Git, sudo access and a valid `npm start` script.
