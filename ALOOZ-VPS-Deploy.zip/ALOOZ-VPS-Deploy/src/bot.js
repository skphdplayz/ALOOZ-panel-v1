require("dotenv").config();
const {
  Client, GatewayIntentBits, Events, PermissionFlagsBits
} = require("discord.js");
const { load, save } = require("./store");
const { run } = require("./ssh");

const token = process.env.DISCORD_TOKEN;
const admins = new Set((process.env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean));
if (!token) throw new Error("DISCORD_TOKEN is missing. Copy .env.example to .env and configure it.");
if (!admins.size) throw new Error("ADMIN_IDS is empty. Add your Discord user ID to .env.");

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const appNameOk = s => /^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$/.test(s);
const labelOk = s => /^[a-zA-Z0-9_-]{1,32}$/.test(s);
const quote = s => "'" + s.replace(/'/g, "'\\''") + "'";
const getServer = name => load().find(s => s.name.toLowerCase() === name.toLowerCase());

async function reply(i, text) {
  const payload = { content: text.slice(0, 1900), ephemeral: true };
  if (i.deferred || i.replied) return i.editReply(payload);
  return i.reply(payload);
}
async function execChecked(server, cmd, timeout) {
  const r = await run(server, cmd, timeout);
  if (r.code !== 0) throw new Error((r.error || r.output || `Remote command failed (${r.code})`).slice(0, 1200));
  return r.output || "Completed.";
}
client.once(Events.ClientReady, c => console.log(`Logged in as ${c.user.tag}`));

client.on(Events.InteractionCreate, async i => {
  if (!i.isChatInputCommand()) return;
  if (!admins.has(i.user.id)) return reply(i, "⛔ এই কমান্ড ব্যবহারের অনুমতি নেই।");
  try {
    const cmd = i.commandName;
    if (cmd === "add-vps") {
      const name = i.options.getString("name", true);
      const host = i.options.getString("host", true);
      const username = i.options.getString("username", true);
      const keyPath = i.options.getString("key_path", true);
      const port = i.options.getInteger("port") || 22;
      if (!labelOk(name) || !/^[a-zA-Z0-9.-]{1,253}$/.test(host) || !/^[a-z_][a-z0-9_-]{0,31}$/i.test(username) || !keyPath.startsWith("/")) {
        return reply(i, "Invalid name, host, username or key path.");
      }
      const items = load();
      if (items.some(s => s.name.toLowerCase() === name.toLowerCase())) return reply(i, "এই নামে VPS আগে থেকেই আছে।");
      items.push({ name, host, port, username, keyPath });
      save(items);
      return reply(i, `✅ VPS **${name}** inventory-তে যোগ হয়েছে। SSH key path: \`${keyPath}\``);
    }

    if (cmd === "vps-list") {
      const items = load();
      return reply(i, items.length ? items.map(s => `• **${s.name}** — \`${s.username}@${s.host}:${s.port || 22}\``).join("\n") : "এখনো কোনো VPS যোগ করা হয়নি।");
    }

    if (cmd === "remove-vps") {
      const name = i.options.getString("name", true);
      const items = load(), next = items.filter(s => s.name.toLowerCase() !== name.toLowerCase());
      if (next.length === items.length) return reply(i, "VPS পাওয়া যায়নি।");
      save(next);
      return reply(i, `🗑️ **${name}** inventory থেকে সরানো হয়েছে। VPS নিজে delete করা হয়নি।`);
    }

    if (cmd === "vps-status") {
      await i.deferReply({ ephemeral: true });
      const s = getServer(i.options.getString("name", true));
      if (!s) return reply(i, "VPS পাওয়া যায়নি। আগে /add-vps ব্যবহার করো।");
      const out = await execChecked(s, "printf 'HOST: '; hostname; printf 'UPTIME: '; uptime -p 2>/dev/null || uptime; printf '\\nDISK: '; df -h / | tail -1; printf '\\nMEMORY: '; free -h | awk '/Mem:/ {print $3 \" used / \" $2}'", 30000);
      return reply(i, `🖥️ **${s.name} status**\n\`\`\`\n${out}\n\`\`\``);
    }

    if (cmd === "deploy-node") {
      await i.deferReply({ ephemeral: true });
      const vps = i.options.getString("vps", true);
      const app = i.options.getString("app", true);
      const repo = i.options.getString("repo", true);
      const branch = i.options.getString("branch") || "main";
      const s = getServer(vps);
      if (!s) return reply(i, "VPS পাওয়া যায়নি। আগে /add-vps ব্যবহার করো।");
      if (!appNameOk(app)) return reply(i, "App name lowercase letters, numbers and hyphens দিয়ে দাও।");
      const u = new URL(repo);
      if (u.protocol !== "https:" || u.hostname !== "github.com" || !/^\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/.test(u.pathname)) return reply(i, "শুধু public HTTPS GitHub repository URL গ্রহণযোগ্য।");
      if (!/^[A-Za-z0-9._/-]{1,80}$/.test(branch) || branch.startsWith("-") || branch.includes("..")) return reply(i, "Invalid branch name.");
      const repoUrl = `https://github.com${u.pathname.replace(/\/$/, "")}.git`;
      const dir = `/opt/alooz-apps/${app}`;
      const safeRepo = quote(repoUrl), safeBranch = quote(branch), safeDir = quote(dir), safeApp = quote(app);
      const script = [
        "set -e",
        "command -v git >/dev/null || (sudo apt-get update -y && sudo apt-get install -y git)",
        "command -v node >/dev/null || { echo 'Node.js 20+ required; install Node.js 20+ first.' >&2; exit 1; }",
        `sudo mkdir -p /opt/alooz-apps && sudo chown "$USER":"$USER" /opt/alooz-apps`,
        `if [ -d ${safeDir}/.git ]; then git -C ${safeDir} fetch --depth 1 origin ${safeBranch}; git -C ${safeDir} checkout ${safeBranch}; git -C ${safeDir} reset --hard FETCH_HEAD; else git clone --depth 1 --branch ${safeBranch} ${safeRepo} ${safeDir}; fi`,
        `cd ${safeDir} && npm ci --omit=dev || npm install --omit=dev`,
        `sudo tee /etc/systemd/system/alooz-${app}.service >/dev/null <<'UNIT'\n[Unit]\nDescription=ALOOZ deployed app ${app}\nAfter=network.target\n[Service]\nType=simple\nWorkingDirectory=${dir}\nExecStart=/usr/bin/npm start\nRestart=on-failure\nRestartSec=5\nUser=${s.username}\nEnvironment=NODE_ENV=production\n[Install]\nWantedBy=multi-user.target\nUNIT`,
        `sudo systemctl daemon-reload && sudo systemctl enable --now alooz-${app}.service`,
        `sudo systemctl --no-pager --full status alooz-${app}.service | head -25`
      ].join("\n");
      const out = await execChecked(s, `bash -lc ${quote(script)}`, 300000);
      return reply(i, `🚀 Deploy complete: **${app}** on **${s.name}**\n\`\`\`\n${out.slice(0, 1300)}\n\`\`\`\nশুধু trusted repository deploy করবে।`);
    }

    if (cmd === "app-restart") {
      await i.deferReply({ ephemeral: true });
      const s = getServer(i.options.getString("vps", true));
      const app = i.options.getString("app", true);
      if (!s || !appNameOk(app)) return reply(i, "VPS বা app name সঠিক নয়।");
      const out = await execChecked(s, `sudo systemctl restart alooz-${app}.service && sudo systemctl is-active alooz-${app}.service`, 30000);
      return reply(i, `♻️ **${app}**: ${out}`);
    }
  } catch (e) {
    console.error(e);
    return reply(i, `❌ কাজটি সম্পন্ন হয়নি: ${String(e.message || e).slice(0, 1200)}`);
  }
});

client.login(token);