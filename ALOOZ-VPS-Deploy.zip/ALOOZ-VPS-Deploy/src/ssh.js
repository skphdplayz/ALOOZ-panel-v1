const fs = require("node:fs");
const { Client } = require("ssh2");

function run(server, command, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    let output = "", errorOutput = "", settled = false;
    const conn = new Client();
    const finish = (err, result) => {
      if (settled) return;
      settled = true;
      conn.end();
      err ? reject(err) : resolve(result);
    };
    const timer = setTimeout(() => finish(new Error("SSH command timed out.")), timeoutMs);
    conn.on("ready", () => {
      conn.exec(command, { pty: false }, (err, stream) => {
        if (err) { clearTimeout(timer); return finish(err); }
        stream.on("data", d => { output += d.toString(); if (output.length > 12000) output = output.slice(-12000); });
        stream.stderr.on("data", d => { errorOutput += d.toString(); if (errorOutput.length > 4000) errorOutput = errorOutput.slice(-4000); });
        stream.on("close", code => {
          clearTimeout(timer);
          finish(null, { code, output: output.trim(), error: errorOutput.trim() });
        });
      });
    }).on("error", err => { clearTimeout(timer); finish(err); });
    let privateKey;
    try { privateKey = fs.readFileSync(server.keyPath); }
    catch (e) { clearTimeout(timer); return finish(new Error(`Cannot read SSH key at configured path: ${e.message}`)); }
    conn.connect({
      host: server.host, port: server.port || 22, username: server.username,
      privateKey, readyTimeout: 15000, keepaliveInterval: 10000,
      hostVerifier: key => {
        // First connection trusts the presented host key. For production, pin known host fingerprints.
        return true;
      }
    });
  });
}
module.exports = { run };