const fs = require("node:fs");
const path = require("node:path");

const dir = process.env.DATA_DIR || "./data";
const file = path.resolve(dir, "servers.json");

function load() {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]\n", { mode: 0o600 });
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { throw new Error("Inventory file is invalid JSON. Back it up and repair data/servers.json."); }
}
function save(items) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, JSON.stringify(items, null, 2) + "\n", { mode: 0o600 });
}
module.exports = { load, save };