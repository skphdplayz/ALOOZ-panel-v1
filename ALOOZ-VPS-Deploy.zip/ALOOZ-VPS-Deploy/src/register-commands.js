require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("add-vps")
    .setDescription("Register an authorized VPS for this bot")
    .addStringOption(o => o.setName("name").setDescription("Short VPS label").setRequired(true))
    .addStringOption(o => o.setName("host").setDescription("VPS IP or hostname").setRequired(true))
    .addIntegerOption(o => o.setName("port").setDescription("SSH port (default 22)").setMinValue(1).setMaxValue(65535))
    .addStringOption(o => o.setName("username").setDescription("SSH username, e.g. ubuntu").setRequired(true))
    .addStringOption(o => o.setName("key_path").setDescription("Absolute path to private SSH key on the bot host").setRequired(true)),
  new SlashCommandBuilder().setName("vps-list").setDescription("List registered VPSs"),
  new SlashCommandBuilder()
    .setName("vps-status").setDescription("Check basic status of a registered VPS")
    .addStringOption(o => o.setName("name").setDescription("VPS label").setRequired(true)),
  new SlashCommandBuilder()
    .setName("deploy-node").setDescription("Deploy a Node.js app from a GitHub repository to a VPS")
    .addStringOption(o => o.setName("vps").setDescription("Registered VPS label").setRequired(true))
    .addStringOption(o => o.setName("app").setDescription("Service name: lowercase letters, numbers, hyphens").setRequired(true))
    .addStringOption(o => o.setName("repo").setDescription("HTTPS GitHub repository URL").setRequired(true))
    .addStringOption(o => o.setName("branch").setDescription("Git branch (default main)")),
  new SlashCommandBuilder()
    .setName("app-restart").setDescription("Restart an app deployed by this bot")
    .addStringOption(o => o.setName("vps").setDescription("Registered VPS label").setRequired(true))
    .addStringOption(o => o.setName("app").setDescription("Service name").setRequired(true)),
  new SlashCommandBuilder()
    .setName("remove-vps").setDescription("Remove a VPS from this bot's local inventory")
    .addStringOption(o => o.setName("name").setDescription("VPS label").setRequired(true))
].map(c => c.toJSON());

async function main() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
    throw new Error("Set DISCORD_TOKEN, CLIENT_ID and GUILD_ID in .env first.");
  }
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
  console.log(`Registered ${commands.length} guild slash commands.`);
}
main().catch(err => { console.error(err.message); process.exit(1); });