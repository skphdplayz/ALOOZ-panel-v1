#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${APP_DIR:-$SCRIPT_DIR}"
REPO_URL="${REPO_URL:-}"
BRANCH="${BRANCH:-main}"

echo "== ALOOZ VPS Deploy Bot installer =="

if [[ $EUID -eq 0 ]]; then
  echo "Run this installer as a normal user, not root."
  exit 1
fi

if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0] < 20))'; then
  echo "Installing Node.js 20..."
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

sudo apt-get update
sudo apt-get install -y git

if [[ -d "$APP_DIR/.git" ]]; then
  git -C "$APP_DIR" pull --ff-only
elif [[ -n "$REPO_URL" ]]; then
  git clone --branch "$BRANCH" "$REPO_URL" "$APP_DIR"
else
  echo "Set REPO_URL to your public GitHub repository, e.g.:"
  echo "REPO_URL=https://github.com/YOURNAME/ALOOZ-VPS-Deploy.git bash install.sh"
  exit 2
fi

cd "$APP_DIR"
npm install --omit=dev
mkdir -p data
chmod 700 data
if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo
  echo "Created $APP_DIR/.env"
  echo "Edit it and add Discord token, application ID, guild ID and admin user ID."
fi

echo
echo "Installation complete."
echo "Next:"
echo "  nano $APP_DIR/.env"
echo "  cd $APP_DIR && npm run register"
echo "  cd $APP_DIR && npm start"
echo
echo "For 24/7 operation, install a process manager or configure the included systemd service after testing."
